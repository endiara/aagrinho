// Variáveis para controlar a posição e o tamanho do círculo
let x;
let y;
let diametro = 50;
let velocidadeX = 2;
let velocidadeY = 3;

// Variáveis para controlar a cor do círculo
let corVermelho;
let corVerde;
let corAzul;

function setup() {
  // Cria uma tela de 600 pixels de largura por 400 de altura
  // Essa função é executada apenas uma vez no início do programa
  createCanvas(600, 400);

  // Define a posição inicial do círculo no centro da tela
  x = width / 2;
  y = height / 2;

  // Define uma cor inicial aleatória para o círculo
  corVermelho = random(255);
  corVerde = random(255);
  corAzul = random(255);
}

function draw() {
  // Define a cor de fundo da tela (preto neste caso)
  // Essa função é executada repetidamente, cerca de 60 vezes por segundo
  background(0);

  // Define a cor do preenchimento do círculo
  fill(corVermelho, corVerde, corAzul);
  // Desenha o círculo na posição (x, y) com o diâmetro especificado
  ellipse(x, y, diametro, diametro);

  // Atualiza a posição do círculo
  x += velocidadeX;
  y += velocidadeY;

  // Verifica se o círculo atingiu as bordas da tela e inverte a direção
  // Se bater na borda direita ou esquerda
  if (x + diametro / 2 >= width || x - diametro / 2 <= 0) {
    velocidadeX *= -1; // Inverte a direção horizontal
    mudarCorAleatoria(); // Muda a cor ao colidir
  }
  // Se bater na borda superior ou inferior
  if (y + diametro / 2 >= height || y - diametro / 2 <= 0) {
    velocidadeY *= -1; // Inverte a direção vertical
    mudarCorAleatoria(); // Muda a cor ao colidir
  }
}

// Função para mudar a cor do círculo para uma cor aleatória
function mudarCorAleatoria() {
  corVermelho = random(255);
  corVerde = random(255);
  corAzul = random(255);
}